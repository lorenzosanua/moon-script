#ifndef _VECTOR2_HPP
#define _VECTOR2_HPP

/*
 * Includes for this file
 */
#include <cstdint>
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <cmath>

namespace Math
{

	/*
	 * 2D vector class
	 */
	class Vector2
	{
	public:

		
		Vector2();

		
		Vector2(float x, float y);

		Vector2 Floor();

		
		 
		Vector2 Ceil();

		
		Vector2 operator - (Vector2 other)
		{
			return {
				x - other.x,
				y - other.y
			};
		}

		/*
		 * Overload Vector2 addition operator
		 */
		Vector2 operator + (Vector2 other)
		{
			return {
				x + other.x,
				y + other.y
			};
		}

		/*
		 * Overload the Vector2 multiplication operator
		 */
		Vector2 operator * (Vector2 other)
		{
			return {
				x * other.x,
				y * other.y
			};
		}

		/*
		 * Overload for the Vector2 division operator
		 */
		Vector2 operator / (Vector2 other)
		{
			return {
				x / other.x,
				y / other.y
			};
		}

		/*
		 * Overload for the add assign operator
		 */
		void operator += (Vector2 other)
		{
			// Update this vector's values
			x += other.x;
			y += other.y;
		}

		/*
		 * Overload for the subtract assign operator
		 */
		void operator -= (Vector2 other)
		{
			// Update this vector's values
			x -= other.x;
			y -= other.y;
		}

		/*
		 * Overload for the multiply assign operator
		 */
		void operator *= (Vector2 other)
		{
			// Update this vector's values
			x *= other.x;
			y *= other.y;
		}

		/*
		 * Overload for the divide assign operator
		 */
		void operator /= (Vector2 other)
		{
			// Update this vector's values
			x /= other.x;
			y /= other.y;
		}

	public: // Public fields for this class
		float x, y;
	};
}
#endif#pragma once
