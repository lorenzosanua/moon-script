#pragma once
#include <stdio.h>
#include <iostream>
#include <Windows.h>
#include <stdlib.h>
#include "LicenseHelpers.h"
#include <string>

using namespace std;

namespace Menu {

	bool loginPage() {
		system("CLS");
		cout << "INSERT KEY: ";
		std::string key;
		cin >> key;
		std::string hwid = LicenseHelpers::getHWID();
		if (LicenseHelpers::connectToServer(key,hwid)) {
			cout << "logged in!";
			return true;
		}
		else {
			cout << "\nbad login";
				return false;
		}
	}


	void mainMenu(int &currentWeapon, int &currentMuzzle, int &currentScope, bool &menuUpdate) {
		
		if (menuUpdate) {
			system("CLS");
			cout << "\n[F5][F6] CURRENT WEAPON: ";
			switch (currentWeapon) {
			case 0:
				cout << "AssaultRifle";
				break;
			case 1:
				cout << "LR300";
				break;
			case 2:
				cout << "MP5A4";
				break;
			case 3:
				cout << "Thompson";
				break;
			case 4:
				cout << "Custom SMG";
				break;
			case 5:
				cout << "M249";
				break;
			}
			cout << "\n[F7][F8] CURRENT SCOPE: ";
			switch (currentScope) {
			case 0:
				cout << "No Scope";
				break;
			case 1:
				cout << "8X Scope";
				break;
			case 2:
				cout << "16X Scope";
				break;
			case 3:
				cout << "Simple Handmade Sight";
				break;
			case 4:
				cout << "Holographic Sight";
				break;
			}
			HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
			SetConsoleTextAttribute(hConsole, 2);
			if (currentMuzzle == 1) cout << "\n[F9] SUPRRESSOR: ON";
			SetConsoleTextAttribute(hConsole, 4);
			if (currentMuzzle == 0) cout << "\n[F9] SUPPRESSOR: OFF";
			SetConsoleTextAttribute(hConsole, 15);
			
			menuUpdate = false;

		}

	}

	void KeyboardInput(int& currentWeapon, int& currentMuzzle, int& currentScope, bool &menuUpdate) {
		if (GetAsyncKeyState(0x74)) {
			currentWeapon--;
			menuUpdate = true;
		}
		if (GetAsyncKeyState(0x75)) {
			currentWeapon++;
			menuUpdate = true;
		}
		if (GetAsyncKeyState(0x76)) { 
			currentScope--; 
			menuUpdate = true;
		}
		if (GetAsyncKeyState(0x77)) {
			currentScope++;
			menuUpdate = true;
		}
		if (GetAsyncKeyState(0x78)) {
			if (currentMuzzle == 0) {
				currentMuzzle++;
			}
			else {
				if (currentMuzzle >= 1) currentMuzzle--;
			}
			menuUpdate = true;
		}
		if (currentWeapon < 0) currentWeapon = 0;
		if (currentWeapon > 5) currentWeapon = 5;
		if (currentScope < 0) currentScope = 0;
		if (currentScope > 4) currentScope = 4;
		Sleep(50);
	}

}