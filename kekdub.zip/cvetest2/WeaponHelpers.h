#pragma once

#include <string>
#include <stdio.h>
#include <stdlib.h>

namespace WeaponHelpers {
	
	int magSize(int weapon) {
		switch (weapon) {
		case 0:
			return 29; //ak
			
		case 1:
			return 29; //lr300
			
		case 2: 
			return 29; //mp5
			
		case 3: 
			return 19; //thompson
			
		case 4:
			return 23; //csmg
			
		case 5:
			return 99; //m249
			
		}
	}

	Math::Vector2* recoilTable(int weapon) {
		switch (weapon) {
		case 0:
			return RecoilTables::AK; //ak
			
		case 1:
			return RecoilTables::LR; //lr300
			
		case 2:
			return RecoilTables::MP5; //mp5
			
		 case 3:
			return RecoilTables::Thompson; //thompson
			break;
		case 4:
			return RecoilTables::CSMG; //csmg
			break;
		case 5:
			return RecoilTables::M249; //m249
			break;
		}

	}

	int weaponRepeatDelay(int weapon) {
		switch (weapon) {
		case 0:
			return 133; //ak
			
		case 1:
			return 120; //lr300
			
		case 2:
			return 100; //mp5
			
		case 3:
			return 130; //thompson
			
		case 4:
			return 100; //csmg
			
		case 5:
			return 120; //m249
			
		}
	}

	struct Attachment {
		float multiplier = 0.0f;
		float firerate = 0.0f;
		Attachment(float multiplier, float firerate) :
			multiplier(multiplier), firerate(firerate) {}
		
	};

	Attachment getAttachmentValues(int attachment) {
		switch (attachment) {
		case 0: //default
			return Attachment(1, 1);
			
		case 1: //silncer
			return Attachment(0.8, 1);
		}
	}

	double getScope(int scope) {
		switch (scope) {
		case 0: //default
			return 1;
		
		case 1: //8x
			return 3.83721;
			
		case 2: //16x
			return 7.65116;
			
		case 3: //simple handmade
			return 0.8;
			
		case 4: //holo
			return 1.18605;
			
		}
	}

	double getFov(int weapon) {
		switch (weapon) {
		case 0: //ak
			return 90;

		case 1: //lr
			return 90;

		case 2: //mp5
			return 92;

		case 3: //thompson
			return 105;

		case 4: //smg
			return 105;
		case 5: //m249
			return 150;

		}
	}
	

	int getRandom() {
		return rand() % 3 - 1;
	}



}