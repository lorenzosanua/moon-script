#include "vector2.hpp"
#include <cstdint>
#include <algorithm>
#include <iostream>
#include <iomanip>



namespace Math
{

	Vector2::Vector2()
	{
	
		x = 0, y = 0;
	}


	Vector2::Vector2(float init_x, float init_y)
	{
		
		x = init_x, y = init_y;
	}

	



	Vector2 Vector2::Floor()
	{
		return {
			std::floor(x),
			std::floor(y)
		};
	}


	Vector2 Vector2::Ceil()
	{
		return {
			std::ceil(x),
			std::ceil(y)
		};
	}


}