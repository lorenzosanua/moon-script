#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <windows.h>
#include "mouse.h"
#include "mouse.c"
#include <stdio.h>
#include "Timer.hpp"
#include "RecoilTables.h"
#include <iostream>
#include <chrono>
#include "WeaponHelpers.h"
#include "MouseHelpers.h"
#include "Menu.h"
#include "LicenseHelpers.h"








int fov = 90;
int currentWeapon = 0;
int currentMuzzle = 0;
int currentScope = 0;
int shotCounter = 0;
float sens = 0.5f;
int smoothing = 6;
bool menuUpdate = true;
bool loggedIn = false;


int main()
{
    if (!mouse_open()) {
        printf("[-] failed to open ghub macro driver\n");
        return 0;
    }
    loggedIn = Menu::loginPage();
    if(!loggedIn) 
       while (1) {
           std::cout << "errore di login";
           system("CLS");
           Sleep(20);
       }
    while (loggedIn)
    {
        
            
        Menu::mainMenu(currentWeapon, currentMuzzle, currentScope, menuUpdate);
        Menu::KeyboardInput(currentWeapon, currentMuzzle, currentScope, menuUpdate);
         // ciclo neutro
        shotCounter = 0;
        
        while (GetAsyncKeyState(VK_LBUTTON) && GetAsyncKeyState(VK_RBUTTON))
        {
            fov = WeaponHelpers::getFov(currentWeapon);
            auto timer = std::chrono::high_resolution_clock::now();
            MouseHelpers::recoil(shotCounter, currentWeapon, fov, sens, currentMuzzle, currentScope, smoothing);
            auto timer_t = std::chrono::high_resolution_clock::now();
            std::cout << "\ntempo netto impiegato = "<< MouseHelpers::timeDelta(timer_t, timer);

        }
      
    }
    system("pause");
    mouse_close();
}


