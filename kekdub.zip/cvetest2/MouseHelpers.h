#pragma once
#include <iostream>
#include <chrono>
#include <stdio.h>
#include <Windows.h>
#include "Vector2.hpp"
#include "mouse.h"
#include "WeaponHelpers.h"

namespace MouseHelpers {


    float timeDelta(std::chrono::high_resolution_clock::time_point t1, std::chrono::high_resolution_clock::time_point t2) {
        float delta = 0.0f;

        std::chrono::duration<double, std::milli> fp_ms = t1 - t2;
        return fp_ms.count();

    }


    void SmoothMove(Math::Vector2 val, int time, int steps) //smoothing func
    {
        int i = 0;
        auto t = std::chrono::high_resolution_clock::now();
        float interval = time / steps;
        while (i < steps) {
            if (timeDelta(std::chrono::high_resolution_clock::now(), t) > interval) {
                mouse_move(0, (val.x / steps), (val.y / steps), 0);
                i++;
                t = std::chrono::high_resolution_clock::now();
                
            }
        }
        mouse_move(0, (int)val.x % steps, (int)val.y % steps, 0); //fixing for conversion
        SleepEx(time % steps, false);
    }

    double readyValue(double value, double sensitivity, double fov) {

        return value / (-0.03f * (sensitivity * 3.0f) * (fov / 100.0f));
    }

    Math::Vector2 finalCoords(Math::Vector2* value, double fov, double sensitivity, unsigned int shotCounter, int muzzle, int scope) {
        double mDeltax;
        double mDeltay;
        double muzzleMultiplier = WeaponHelpers::getAttachmentValues(muzzle).multiplier;
        double scopeMultiplier = WeaponHelpers::getScope(scope);
        Math::Vector2 finalVector;

        if (shotCounter >= 1) {
            mDeltax = (value[shotCounter].x - value[shotCounter - 1].x) * scopeMultiplier * muzzleMultiplier;
            mDeltay = (value[shotCounter].y - value[shotCounter - 1].y) * scopeMultiplier * muzzleMultiplier;
        }
        else {
            mDeltax = value[shotCounter].x * scopeMultiplier * muzzleMultiplier;
            mDeltay = value[shotCounter].y * scopeMultiplier * muzzleMultiplier;
        }

        finalVector.x = readyValue(mDeltax, sensitivity, fov);
        finalVector.y = readyValue(mDeltay, sensitivity, fov);
        
        return finalVector;
    }



    float animationTime(unsigned int shotCounter, int weapon, int muzzle) {
        float anim_time = sqrt(pow(WeaponHelpers::recoilTable(weapon)[shotCounter].x - WeaponHelpers::recoilTable(weapon)[shotCounter - 1].x, 2) + pow(WeaponHelpers::recoilTable(weapon)[shotCounter].y - WeaponHelpers::recoilTable(weapon)[shotCounter - 1].y, 2)) / 0.02f;

        if (shotCounter == 0) anim_time = sqrt(pow(WeaponHelpers::recoilTable(weapon)[shotCounter].x, 2) + pow(WeaponHelpers::recoilTable(weapon)[shotCounter].y, 2)) / 0.02f;
        
        
        return anim_time;
    }


    void recoil(int &shotCounter, int currentWeapon, int fov, float sens, int currentMuzzle, int currentScope, int smoothing) {

        if (shotCounter < WeaponHelpers::magSize(currentWeapon))
        {
            
            Math::Vector2 coords = finalCoords(WeaponHelpers::recoilTable(currentWeapon), fov, sens, shotCounter, currentMuzzle, currentScope); //get coords
            
            float animation_time = animationTime(shotCounter, currentWeapon, currentMuzzle); // get anim time

            auto t_timer = std::chrono::high_resolution_clock::now();

            //if (shotCounter == 2 && currentWeapon == 0) animation_time -= 5;
           
            SmoothMove(coords, animation_time, smoothing);
            shotCounter++;
            auto t_recoil = std::chrono::high_resolution_clock::now();
            float elapsed_time = timeDelta(t_recoil, t_timer); //time taken to recoil a full set of angles
            

            float timeDiff = WeaponHelpers::weaponRepeatDelay(currentWeapon) - elapsed_time; //time between elapsed and repeat

            if (WeaponHelpers::weaponRepeatDelay(currentWeapon) - elapsed_time > 0) SleepEx(timeDiff, false); // sleep
            std::cout << "\n" << elapsed_time << " differenza = " << timeDiff;
            
            //std::cout << "\n " << timeDiff << "for shot" <<  shotCounter << " time "<< elapsed_time;



        }
    }


}


